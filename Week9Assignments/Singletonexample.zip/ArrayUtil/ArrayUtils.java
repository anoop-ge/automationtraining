package ArrayUtil;





public class ArrayUtils {
	private int array[];
	private static boolean object_created = false;

	
	private static ArrayUtils obj=null;

	//constructor
	private ArrayUtils(int array[]) {
		this.array = array;
	}
	
	public static ArrayUtils getInstance(int array[]) {
		if(object_created == false) {
			obj = new ArrayUtils(array);
			object_created = true;
		}
		else {
		  System.out.println("Returning existing Object");
			return obj;
		  
		}
		return obj;
	}
	
	public int min() {
		int min_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min_val) {
				min_val = array[i];
			}
		}

		return min_val;
	}
	public int max() {
		int max_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] > max_val) {
				max_val = array[i];
			}
		}

		return max_val;
	}
}