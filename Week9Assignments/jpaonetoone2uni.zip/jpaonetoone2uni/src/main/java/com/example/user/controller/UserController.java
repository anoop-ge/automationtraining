

package com.example.user.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.Profile;
import com.example.user.model.User;
import com.example.user.service.UserService;

@RestController
public class UserController {
	private static final Logger logger=LoggerFactory.getLogger(UserController.class);

public void userController() {
	
	logger.debug("User Controller() invokde");
}
	


@Autowired
	
	private UserService uservice;
	
@PostMapping

	public User createUser(@RequestBody User user){
	logger.info("Post method invokded");
		return uservice.createUser(user);
	}

@GetMapping("/{userid}")

public User getUser(@PathVariable long userid) {
	
	return uservice.getUser(userid);
}

@GetMapping("/prof/{profid}")
public Profile getProf(@PathVariable long profid) {
	return uservice.getProfile(profid);
}


}

