//Program For Returning existing object
package ArrayStringSorting;
import java.util.Scanner;

import ArrayUtil.ArrayUtils;


public class App {
public static void main(String[] args) {
	
	String[] students=new String[]{"abc","sxd","xyz","tt","yyy","aaaa"};
	
	StringCompare obj = StringCompare.getInstance(students);
	String min_result = obj.min();
	System.out.println("Minimum Value"+min_result);
	
	StringCompare obj1 = StringCompare.getInstance(students);
	String max_result = obj1.max();
	
	System.out.println("Max Value:"+max_result);
	
}
}