package ArrayStringSorting;


/*
1. Make constructor private
2. Create a static method for object creation
3. In above method create object only if not already created
4. use static member to find object already created
 */


//Singleton - Returning existing object.


public class StringCompare {
	private String array[];
	private static boolean object_created = false;

	
	private static StringCompare obj=null;

	//constructor
	private StringCompare(String array[]) {
		this.array = array;
	}
	
	public static StringCompare getInstance(String array[]) {
		if(object_created == false) {
			obj = new StringCompare(array);
			object_created = true;
		}
		else {
		  System.out.println("Returning existing Object");
			return obj;
		  
		}
		return obj;
	}
	
	public String min() {
		String min_val = array[0];
		for (int i = 0; i < array.length; i++) {
		if (array[i].compareToIgnoreCase(min_val)<0 ){
				min_val = array[i];
			}
		}

		return min_val;
	}
	public String max() {
		String max_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i].compareToIgnoreCase(max_val)>0) {
				max_val = array[i];
			}
		}

		return max_val;
	}
}