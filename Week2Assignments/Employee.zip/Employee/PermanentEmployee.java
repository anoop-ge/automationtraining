package com.p1;
import com.p1.Employee;

	public class PermanentEmployee  extends Employee
	{

	    String add;
	    float salary;
	    
	    
	    public PermanentEmployee(int empid,String name, float salary, String add)
	    {
//	    	super(empid,name);
	    	this.salary=salary;
	    	this.add=add;
	    }


		public String getAdd() {
			return add;
		}


		public void setAdd(String add) {
			this.add = add;
		}


		public float getSalary() {
			return salary;
		}


		public void setSalary(float salary) {
			this.salary = salary;
		}
	    
		
		

		

	}

	
	
	

