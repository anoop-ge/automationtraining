package com.p1;

public class TemporaryEmployee extends Employee{
	
private int duration;
private float salary;
public TemporaryEmployee(int empid,String name,int duration, float salary) {
	super(empid,name);
	this.duration = duration;
	this.salary = salary;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}

public void display() {
	
	System.out.println("Contract Period"+duration+"Salary is "+salary);
}


	
	
}