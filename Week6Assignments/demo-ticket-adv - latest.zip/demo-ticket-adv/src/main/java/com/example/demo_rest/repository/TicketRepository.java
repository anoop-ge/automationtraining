package com.example.demo_rest.repository;


import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.example.demo_rest.model.Ticket;

@Repository

public class TicketRepository {

	private HashMap<Integer, Ticket> tickets;

	public TicketRepository() {

		tickets = new HashMap<>();
		tickets.put(1, new Ticket(1, "Place A", "Place B", 10000));
		tickets.put(2, new Ticket(2, "Place C", "Place D", 12222));
		tickets.put(3, new Ticket(3, "Place E", "Place F", 24132));

	}

	public Ticket getTicketRepo(int ticketid) {

		Ticket ticket = tickets.get(ticketid);

		return ticket;
	}

	public Ticket bookTicketRepo(Ticket ticket) {

		tickets.put(ticket.getId(), ticket);

		return ticket;

	}

	public Ticket updateTicketRepo(int id, Ticket ticket) {

		tickets.replace(id, ticket);

		return ticket;

	}

	public int cancelTicket(int ticketid) {

		Ticket ticket = tickets.remove(ticketid);

		return ticketid;

	}

}
