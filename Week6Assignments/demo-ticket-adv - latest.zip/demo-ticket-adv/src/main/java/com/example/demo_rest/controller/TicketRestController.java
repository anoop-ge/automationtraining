package com.example.demo_rest.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo_rest.model.Ticket;
import com.example.demo_rest.service.TicketService;
import com.example.demo_rest.exception.InvalidTicketIDException;
import com.example.demo_rest.exception.InvalidPlaceNameException;


@RestController
@RequestMapping("/ticket")
public class TicketRestController {

	@Autowired
	TicketService tservice;

	

	@GetMapping("/{tid}")
	ResponseEntity<Ticket> getTicket(@PathVariable("tid") int ticketid) {

		Ticket ticket = tservice.getTicketServ(ticketid);
		
		if(ticket == null) {
			throw new InvalidTicketIDException("No such ticket  exists");
		}

		return new ResponseEntity<Ticket>(ticket, HttpStatus.OK);

	
	}

	
	@PostMapping("/book")
	ResponseEntity<Ticket> bookTicket(@RequestBody Ticket ticket,@RequestHeader(value="x-header") String xheader) {

		
		System.out.println(xheader);
		
		
		if(ticket.getTo_place() == null || ticket.getFrom_place() == null) {
			throw new InvalidPlaceNameException("Place Empty or null or doesnt Exist");
		}
		Ticket ticketb=tservice.bookTicketServ(ticket);		
		HttpHeaders headers=new HttpHeaders();
		
		headers.add("x-response-hdr", "somevalue");
		return new ResponseEntity<Ticket>(ticketb,headers, HttpStatus.CREATED);
	
		
	}

	@PutMapping("/update/{tid}")
	ResponseEntity<Ticket> update(@PathVariable("tid") Integer tid, @RequestBody Ticket ticket) {
		

	
		Ticket ticketu=tservice.updateTicketRepo(0, ticket);
		return new ResponseEntity<Ticket>(ticketu, HttpStatus.CREATED);
	}

	@DeleteMapping("/{tid}")
	ResponseEntity<Integer> cancel(@PathVariable("tid") Integer ticketid) {
		Ticket ticket = tservice.cancelTicket(ticketid);
		if(ticket == null) {
			throw new InvalidTicketIDException("No such ticket  exists");
		}
		return new ResponseEntity<Integer>(ticketid, HttpStatus.CREATED);
	}
}
