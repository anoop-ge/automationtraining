package com.example.demo_rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo_rest.model.Ticket;
import com.example.demo_rest.repository.TicketRepository;

@Service
public class TicketService {

	@Autowired

	public TicketRepository ticketrepo;

	// Dependency Injection

	public Ticket getTicketServ(int ticketid) {

		return ticketrepo.getTicketRepo(ticketid);

	}

	public Ticket bookTicketServ(Ticket ticket) {
		return ticketrepo.bookTicketRepo(ticket);

	}

	public Ticket updateTicketRepo(int id, Ticket ticket) {

		return ticketrepo.updateTicketRepo(id, ticket);

	}

	public Ticket cancelTicket(int ticketid) {

		Ticket ticket = ticketrepo.getTicketRepo(ticketid);

		ticketrepo.cancelTicket(ticketid);

		return ticket;
	}

}
