package com.example.demo_rest;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tickets")

public class DemoRestController {

	Ticket tickets;

	// Map<String, String> hmss=new HashMap<>();
	Map<Integer, Ticket> ticketmap;

	public DemoRestController() {

		System.out.println("inside constructor");

		ticketmap = new HashMap<>();
		
		ticketmap.put(1, new Ticket(1,"name", "address1",4));
	}

	@GetMapping("/abcd")
	public String met() {
		return "Hello123";

	}

	@GetMapping("/ticket")

	Ticket getUser(@RequestParam("id") int ticketid)

	{
		Ticket ticket = ticketmap.get(ticketid);

		return ticket;

	}

	@PostMapping("book")

	Ticket bookTicket(@RequestBody Ticket ticket) {

		System.out.println("Booking Ticket+" + ticket);

		
		ticketmap.put(ticket.id, ticket);
		return ticket;

	}

	@DeleteMapping("cancel")

	String canelTicket(@RequestParam("id") int ticketid) {

		ticketmap.remove(ticketid);
		return "Ticket with ticketid " + ticketid + " `is cancelled.";

	}

}
