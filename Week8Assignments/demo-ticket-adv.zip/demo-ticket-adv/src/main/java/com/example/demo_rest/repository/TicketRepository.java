package com.example.demo_rest.repository;


import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo_rest.model.Ticket;

@Repository

public interface TicketRepository extends JpaRepository<Ticket,Integer> 

//public interface TicketRepository extends CrudRepository<Ticket,Integer>

//public interface TicketRepository extends PagingAndSortingRepository<Ticket,Integer>

{
	

	
public List<Ticket> findByFromplaceOrToplace(String fromplace, String toplace);

// Retrieve all ticket from a specific place.
@Query("SELECT w FROM Ticket w WHERE w.fromplace=:fromplace")

List<Ticket> averagePrice(@Param("fromplace" ) String str);

public List<Ticket> findByFromplaceOrToplaceAndPriceLessThan(String fromplace,String toplace,float price);


@Query(value="SELECT * FROM Ticket where username=:uname",nativeQuery=true)

List<Ticket> getAllTickets(@Param("uname") String username);
//Assignment Use of MOdifying Transactional along with Query to reduce ticket price 10% for a user.

@Modifying
@Transactional
@Query("UPDATE Ticket t SET t.price=t.price*0.9 WHERE t.username=:uname")
void updateTicket(@Param("uname") String username);



}



