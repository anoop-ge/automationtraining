package com.example.demo_rest.model;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

//@Component
@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@NotNull
	@Column
	private String fromplace;
	@Column

	private String toplace;
	@Column
	@DecimalMin("99.9")
	@DecimalMax("10000")
	private float price;

	
	@Min(value=1)
	@Max(value=10)
	private int numberofseats;
	
	

	@NotNull(message =" Username can't be blank")
	@Column

	private String username;
	
	@Email
	@NotNull
	@Column
	private String email;
	
	@Future(message="Date should be future")
	private Date traveldate;
	 
	@Pattern(regexp="^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$")
	String pincode;
	

	
	public Date getTraveldate() {
		return traveldate;
	}

	public void setTraveldate(Date traveldate) {
		this.traveldate = traveldate;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	

	
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	public int getNumberofseats() {
		return numberofseats;
	}

	public void setNumberofseats(int numberofseats) {
		this.numberofseats = numberofseats;
	}

	public Ticket() {}
	
	public Ticket(int id, String from_place, String to_place, float price,String username,String email,Date traveldate,String pincode,int numberofseats) {
		super();
		this.id = id;
		this.fromplace = from_place;
		this.toplace = to_place;
		this.price = price;
		this.username=username;
		this.email=email;
		this.traveldate=traveldate;
		this.pincode=pincode;
		this.numberofseats=numberofseats;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFromplace() {
		return fromplace;
	}

	
	public void setFromplace(String from_place) {
		this.fromplace = from_place;
	}

	public String getToplace() {
		return toplace;
	}

	public void setToplace(String to_place) {
		this.toplace = to_place;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", fromplace=" + fromplace + ", toplace=" + toplace + ", price=" + price
				+ ", numberofseats=" + numberofseats + ", username=" + username + ", email=" + email + ", traveldate="
				+ traveldate + ", pincode=" + pincode + "]";
	}



	

}
