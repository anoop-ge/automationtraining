package com.example.demo_resttemplate;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.params.provider.Arguments;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ExcelReadUtils {

	private static Workbook wb;
	private static Sheet st;
	
	private static int current_row_num;
	
	public static void init() {
		
		try {
			
			
		}
		catch(Exception e){
			
			
		}
		
	}
	
	public static Stream<Arguments> fetchTicketIds() {
		List<Arguments> args = new ArrayList<>();
		try {
			// read from excel
			// create Stream
			// and return, Stream
			FileInputStream fis = new FileInputStream("C:\\Book1.xlsx");

			// read workbook
			Workbook wbook = new XSSFWorkbook(fis);

			double value = 0;

			int no_of_rows = 0;
			Sheet st = null;

			// read sheet
			st = wbook.getSheetAt(0);

			//fetch no.of rows in excel
			no_of_rows = st.getPhysicalNumberOfRows();

			for (int i = 0; i < no_of_rows; i++) {
				// fetch each rows
				Row row = st.getRow(i);

				int no_of_cols = row.getLastCellNum();

				// read first column - ticketid
				Cell cell1 = row.getCell(0);
				int ticketid = (int) cell1.getNumericCellValue();
				
				// read second  column - fromplace
				Cell cell2 = row.getCell(1);
				String fromplace = cell2.getStringCellValue();
				
				// read third column - toplace
				Cell cell3 = row.getCell(2);
				String toplace = cell3.getStringCellValue();

				// read fourth column - price
				Cell cell4 = row.getCell(3);
				float price = (float) cell4.getNumericCellValue();
				
				args.add(Arguments.of(ticketid, fromplace, toplace, price));
			}

			wbook.close();
			fis.close();
		} catch (Exception e) {
			System.out.println("Exceptionnnn"+e.getMessage());
			e.printStackTrace();
		}

		//create and return stream from list of Junit arguments
		return args.stream();
	}
	
	public static Stream<Arguments> readTicketJson() {
		List<Arguments> args = new ArrayList<>();
		try {
			// read from excel
			// create Stream
			// and return, Stream
			FileInputStream fis = new FileInputStream("C:\\Book2.xlsx");

			// read workbook
			Workbook wbook = new XSSFWorkbook(fis);

			double value = 0;

			int no_of_rows = 0;
			Sheet st = null;

			// read sheet
			st = wbook.getSheetAt(0);

			//fetch no.of rows in excel
			no_of_rows = st.getPhysicalNumberOfRows();

			for (int i = 0; i < no_of_rows; i++) {
				// fetch each rows
				Row row = st.getRow(i);

				int no_of_cols = row.getLastCellNum();

				// read first column - ticket json
				Cell cell1 = row.getCell(0);
				String ticketjson = cell1.getStringCellValue();
				
				Cell cell2=row.getCell(1);
				String username=cell2.getStringCellValue();
				
				args.add(Arguments.of(ticketjson,username));
			}

			wbook.close();
			fis.close();
		} catch (Exception e) {
			System.out.println("Exceptionnnn"+e.getMessage());
			e.printStackTrace();
		}

		//create and return stream from list of Junit arguments
		return args.stream();
	}
	
	
	Ticket fetchTicket(ResultActions resultActions) throws Exception{
	  String jsonresponse = resultActions.andReturn().getResponse().getContentAsString();
	  System.out.println("Json Response: "+jsonresponse);
	  
	  //json string to json obj 
	  ObjectMapper omapper = new ObjectMapper();
	  Ticket ticket = omapper.readValue(jsonresponse, Ticket.class);
	  return ticket;
	}
}
