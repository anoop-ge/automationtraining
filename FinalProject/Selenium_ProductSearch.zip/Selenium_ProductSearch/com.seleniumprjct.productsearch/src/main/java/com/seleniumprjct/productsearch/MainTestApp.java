package com.seleniumprjct.productsearch;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.excel.utils.ExcelReadUtils;
import com.excel.utils.ExcelWriteUtils;

public class MainTestApp {

	private static WebDriver driver;

	@BeforeAll
	public static void setUp() {
		// set driver property
		// Set the path for the ChromeDriver
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\chromedriver.exe");

		// Create a new instance of the Chrome driver
		driver = new ChromeDriver();


		System.out.println("setUp....1");
		ExcelReadUtils.init();
		ExcelWriteUtils.init();

	}

	static Stream<Arguments> getProductDetails() {
		System.out.println("getProductDetails....1");
		// invoke ExcelReadUtils method
		Stream<Arguments> productdetails = ExcelReadUtils.getProductDetails();
		return productdetails;
	}

	@ParameterizedTest
	@MethodSource("getProductDetails")
	public void searchProductTest(String testcaseid, String productname,String result) throws InterruptedException {
		try {
			driver.get(
					"C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumprjct.productsearch\\src\\main\\resources\\ProductSearch.html");

			ProductSearch psearch = new ProductSearch(driver);

			Thread.sleep(3000);

			psearch.inputSearch(productname);

			Thread.sleep(3000);
			
			String searchresult = psearch.submitSearch();
			
			Thread.sleep(3000);

			assertTrue(searchresult.contains(result));

			ExcelWriteUtils.writeTCResult(testcaseid, "PASS", "");

		} catch (AssertionError ae) {

			ExcelWriteUtils.writeTCResult(testcaseid, "FAIL", ae.getMessage());
			throw ae;

		}

		catch (Exception e) {

			ExcelWriteUtils.writeTCResult(testcaseid, "ERROR", "");

			System.out.println("Exception ...." + e.getMessage());
			e.printStackTrace();
			throw e;
		}

	}

	@AfterAll
	public static void tearDown() {
		System.out.println("tearDown");
		ExcelWriteUtils.generateExcel();
		if (driver != null) {
			driver.quit();
		}
	}

}
