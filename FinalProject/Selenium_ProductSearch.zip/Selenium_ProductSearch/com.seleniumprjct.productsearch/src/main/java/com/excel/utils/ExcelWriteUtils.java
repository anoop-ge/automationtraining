package com.excel.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriteUtils {

	private static Workbook wbook;

	private static Sheet sheet;

	private static int row_num;

	public static void init() {
		try {

			// create workbook
			wbook = new XSSFWorkbook();

			// create sheet
			sheet = wbook.createSheet();

			System.out.println("init.....1:" + sheet);
		} catch (Exception e) {
			System.out.println("Exceptionn ...." + e.getMessage());

			e.printStackTrace();
		}
	}

	public static void writeTCResult(String testcaseid, String testcaseresult, String details) {

		Row row = sheet.createRow(row_num++);

		Cell tc_idcell = row.createCell(0, CellType.STRING);

		tc_idcell.setCellValue(testcaseid);

		Cell tc_result = row.createCell(1, CellType.STRING);

		tc_result.setCellValue(testcaseresult);
		
		Cell message = row.createCell(2, CellType.STRING);

		message.setCellValue(details);
	}

	public static void generateExcel() {

		try {
			FileOutputStream fos = new FileOutputStream("./testreport.xlsx");
			wbook.write(fos);
			wbook.close();
			fos.close();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
