package com.seleniumprjct.productsearch;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductSearch {

	private WebDriver driver;
	
	private By searchtxt = By.id("searchInput");	
	
	private By searchbtn = By.xpath("/html/body/div[1]/button");	
	
	private By results = By.id("results");
	
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	
	public ProductSearch(WebDriver driver) {
		
		this.driver=driver;
	}
	
	//Method for searching a product
	public void inputSearch(String product) {
		
	WebElement search=driver.findElement(searchtxt);
	
	search.sendKeys(product);
		
	}
	
	public String submitSearch() {
		
		WebElement submit=driver.findElement(searchbtn);
		
        submit.click();	
        
        
        WebElement resulttxt=driver.findElement(results);
        
        String searchresult=resulttxt.getText();
        
        return searchresult;
		}

	

}
