package com.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.product.repository.*;
import com.product.exception.InsufficientQuantityException;
import com.product.model.Product;

@Service
public class ProductService {

	@Autowired
	ProductRepository pRepo;

	// Retrieve LIst of Products
	public Product getProduct(String productname) {
		Product product = pRepo.findByProductsByName(productname);
		return product;
	}

	public Product updateProductQuantity(int productid, Product product) {

		Product pdetails = pRepo.findById(productid).get();

		if (pdetails.getQuantity() > product.getQuantity()) {

			System.out.println("Available Qty" + pdetails.getQuantity());
			System.out.println("requested Quantity" + product.getQuantity());

			int uquantity = pdetails.getQuantity() - product.getQuantity();

			pdetails.setQuantity(uquantity);
			Product uproduct = pRepo.save(pdetails);
			// pRepo.buyProduct(productid, product.getQuantity());//Error is showing while
			// trying to retrieve Product using Update QUery..
			// FindByID is not retrieving the updated quantity after the update..it is
			// fetching the old details immediately after that. Because of that save is used.

			return uproduct;

		}

		else
			throw new InsufficientQuantityException("Requested Quantity is greater than the quanity in store");
	}

}
