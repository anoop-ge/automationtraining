package com.product.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.product.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	// Retrieve matching products from the database
	@Query("SELECT p FROM Product p WHERE p.name =:productname")
	public Product findByProductsByName(@Param("productname") String productname);

	// Update product quantity.This is not using instead of that save is using in
	// the service to return product object.

	@Modifying
	@Transactional
	@Query("UPDATE Product p SET p.quantity=p.quantity-:dquantity WHERE p.id=:productid")
	public void buyProduct(@Param("productid") int productid, @Param("dquantity") int dquantity);

}
