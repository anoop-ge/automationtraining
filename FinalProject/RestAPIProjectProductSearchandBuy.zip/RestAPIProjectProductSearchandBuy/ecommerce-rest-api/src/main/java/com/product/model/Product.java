package com.product.model;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//@Component
@Entity
@Table(name="Product")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String name;
	
	private int quantity;

	private float unitprice;


	public Product() {
	}

	public Product(int id, String name, int quantity, float unitprice) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.unitprice = unitprice;
	}

	public String getProductname() {
		return name;
	}

	public void setProductname(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getUnitprice() {
		return unitprice;
	}

	public void setUnitprice(float unitprice) {
		this.unitprice = unitprice;
	}

	public int getProductId() {
		return id;
	}
		
	public void setProductId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Product [productid=" + id + ", productname=" + name + ", quantity=" + quantity
				+ ", unitprice=" + unitprice + "]";
	}

	
}
