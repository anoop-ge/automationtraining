package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Product;
import com.product.service.ProductService;

@RestController
@RequestMapping("/ecom")
public class ProductController {

	@Autowired
	ProductService pservice;

	// Search Product based on product name

	@GetMapping("/{productname}")
	public ResponseEntity<Product> getProduct(@PathVariable("productname") String name) {
		Product product = pservice.getProduct(name);

		if (product == null) {

			return ResponseEntity.notFound().build();
		} else
			return new ResponseEntity<Product>(product, HttpStatus.OK);

	}

	// Update the product by deducting the given quantity.

	@PutMapping("/buy/{pid}")
	public ResponseEntity<Product> updateProduct(@PathVariable("pid") int id, @RequestBody Product product) {

		System.out.println(id);
		System.out.println(product.getQuantity());
		Product uproduct = pservice.updateProductQuantity(id, product);
		return new ResponseEntity<Product>(uproduct, HttpStatus.OK);

	}

}
