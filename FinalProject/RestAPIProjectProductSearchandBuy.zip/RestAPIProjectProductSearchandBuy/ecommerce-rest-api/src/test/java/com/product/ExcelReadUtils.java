package com.product;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.params.provider.Arguments;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.model.Product;

import jakarta.annotation.PostConstruct;

@Component
public class ExcelReadUtils {
	private static Workbook wbook;
	private static Sheet sheet;
	private static int current_row_num;

	public static void init() {
		try {
			// For reading Excel file path from json file.
			ObjectMapper omapper = new ObjectMapper();
			FileInputStream sfis = new FileInputStream("./settings.json");
			CustomProperties obj = omapper.readValue(sfis, CustomProperties.class);
			System.out.println("Path:" + obj.getIexcelpath());

			// Opening Excel file

			FileInputStream fis = new FileInputStream(obj.getIexcelpath());
			wbook = new XSSFWorkbook(fis);
			sheet = wbook.getSheetAt(0);
			current_row_num = 0;

		} catch (Exception en) {
			System.out.println("Exception in initt" + en.getMessage());
		}
	}

	// Reading Productname from Excel for searching product details.(GET)

	public static Stream<Arguments> fetchProduct() {
		System.out.println("In Fetch ProductNames");
		List<Arguments> args = new ArrayList<>();

		// fetch no. of test data rows(N), dynamically
		Row row = sheet.getRow(current_row_num++);
		Cell cell1 = row.getCell(0);
		int num_of_testcases = (int) cell1.getNumericCellValue();
		System.out.println("num_of_testcases" + num_of_testcases);
		// fetch N number of rows and return Stream<Arguments>

		try {
			for (int i = current_row_num; i < (current_row_num + num_of_testcases); i++) {

				
				Row rowi = sheet.getRow(i);
				System.out.println("current_row_num" + current_row_num);
				
				// read first column - testcaseid
				Cell cellid = rowi.getCell(0);
				String testcaseid = cellid.getStringCellValue();
				
				// read second column - productname

				Cell cellpname = rowi.getCell(1);
				String productname = cellpname.getStringCellValue();

				// read third col - price
				Cell cellpprice = rowi.getCell(2);
				float price= (float)cellpprice.getNumericCellValue();

				
				args.add(Arguments.of(testcaseid,productname, price));
			}

			current_row_num = current_row_num + num_of_testcases;

		} catch (Exception e) {
			System.out.println("Exceptionnnn:" + e.getMessage());
			e.printStackTrace();
		}
		// create and return Stream from List of JUnit Arguments

		return args.stream();
	}

	
	// Reading Json from Excel for updating the Product quantity .(PUT)

	public static Stream<Arguments> readBuyProduct() {
		List<Arguments> args = new ArrayList<>();

		System.out.println("In Product quantity update");

		try {

			Row row = sheet.getRow(current_row_num++);
			Cell cell1 = row.getCell(0);
			int num_of_testcases = (int) cell1.getNumericCellValue();
			System.out.println("num_of_testcases" + num_of_testcases);
			// fetch N number of rows and return Stream<Arguments>

			System.out.println("Current Row Number in update" + current_row_num);
			// 1,2,3,4
			for (int i = current_row_num; i < (current_row_num + num_of_testcases); i++)

			{
				// fetch each row
				Row rowcol = sheet.getRow(i);

				// reading testcaseid from firstcolumn
				Cell cellid = rowcol.getCell(0);
				String tcid = cellid.getStringCellValue();

				//reading pid data from second column	
				Cell cellpid = rowcol.getCell(1);
				int pid =(int)cellpid.getNumericCellValue();

				
				//reading json data from third column	
				Cell cellproductjson = rowcol.getCell(2);
				String productjson = cellproductjson.getStringCellValue();

				
				//reading quantity data from fourth column	
				Cell cellpquanity = rowcol.getCell(3);
				int quantity =(int)cellpquanity.getNumericCellValue();

				// add each Test data bundle to List
				args.add(Arguments.of(tcid,pid, productjson,quantity));

			}
			current_row_num = current_row_num + num_of_testcases;
			
			System.out.println("Current rownum after update"+current_row_num);

		} catch (Exception e) {
			System.out.println("Exception:" + e.getMessage());
			e.printStackTrace();
		}

		// create and return Stream from List of JUnit Arguments
		return args.stream();
	}



}
