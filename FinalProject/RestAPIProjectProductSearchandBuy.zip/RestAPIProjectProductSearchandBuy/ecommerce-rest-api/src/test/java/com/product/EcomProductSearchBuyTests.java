package com.product;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.model.Product;

import jakarta.annotation.PostConstruct;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import org.springframework.test.web.servlet.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

class EcomProductSearchBuyTests {
	@Autowired
	private MockMvc mockMvc;

	private static Workbook wbook;

	static Sheet st;
	@Autowired
	ExcelReadUtils eRUtils;

	@Autowired
	ExcelWriteUtils eWUtils;

	@BeforeAll
	static void createExcel() throws IOException {

		ExcelReadUtils.init();
		wbook = new XSSFWorkbook();

		// create a new sheet
		st = wbook.createSheet("First Sheet");
	}

	@BeforeEach
	void met() {

	}

	// Method For Fetching product id s from excel for GET ticket
	public static Stream<Arguments> getProduct() {
		return ExcelReadUtils.fetchProduct();
	}

	// Test For Get Product using Productname.

	@ParameterizedTest
	@Order(1)
	@MethodSource("getProduct")
	void testGetProduct(String testcaseid, String productname, float price) throws Exception {
		try {
			// sending requests for getting the products.
			mockMvc.perform(get("/ecom/" + productname)).andExpect(status().isOk())
					.andExpect(content().contentType(MediaType.APPLICATION_JSON))
					// .andExpect(jsonPath("$.quantity").value(quantityn))
					.andExpect(jsonPath("$.productname").value(productname))
					.andExpect(jsonPath("$.unitprice").value(price)).andDo(print());

		} catch (AssertionError ae) {
			eWUtils.createTestResultRow("TestCase: " + testcaseid + "Failed", ae.getMessage(), st);
			throw ae;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			eWUtils.createTestResultRow("TestCase: " + testcaseid + "Error", e.getMessage(), st);
		}

		// create row in excel
		// create row
		eWUtils.createTestResultRow("TestCase:" + testcaseid + " Passed", "", st);
	}

	public static Stream<Arguments> excelBuyProduct() {
		return ExcelReadUtils.readBuyProduct();
	}

	
	//Test for updating the product quantity while triggering the buy request.
	@ParameterizedTest
	@Order(2)
	@MethodSource("excelBuyProduct")
	void testBuyProduct(String testcaseid, int productid, String productjson, float uquantity) throws Exception {

		try {

			System.out.println("inupdate");
			mockMvc.perform(put("/ecom/buy/"+productid).contentType(MediaType.APPLICATION_JSON).content(productjson))
					.andExpect(status().isOk()).andExpect(jsonPath("$.quantity").value(uquantity));

		}

		catch (AssertionError e) {

			eWUtils.createTestResultRow("TestCase:" + testcaseid + " Failed", e.getMessage(), st);
			throw e;

		}

		eWUtils.createTestResultRow("TestCase:" + testcaseid + " Passed", "", st);

	}

	@AfterAll
	static void tearDown() {
		try {
			// close excel
			FileOutputStream fos = new FileOutputStream("testreport.xlsx");
			// write above excel to a file
			wbook.write(fos);
			wbook.close();
			fos.close();
		} catch (Exception e) {
			System.out.println("Exceptionaa:" + e.getMessage());
		}
	}

}
