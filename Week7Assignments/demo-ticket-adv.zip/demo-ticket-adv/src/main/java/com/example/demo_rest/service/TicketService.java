package com.example.demo_rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo_rest.model.Ticket;
import com.example.demo_rest.repository.TicketRepository;

@Service
public class TicketService {

	@Autowired

	public TicketRepository ticketrepo;

	// Dependency Injection

	public Ticket getTicketServ(int ticketid) {

		Optional<Ticket> oticket = ticketrepo.findById(ticketid);
		return oticket.get();

	}

	public Ticket bookTicketServ(Ticket ticket) {
		return ticketrepo.save(ticket);

	}

	public Ticket updateTicketRepo(int id, Ticket ticket) {
		Ticket eticket = ticketrepo.findById(id).get();
		eticket.setFromplace(ticket.getFromplace());
		eticket.setToplace(ticket.getToplace());
		eticket.setPrice(ticket.getPrice());

		return ticketrepo.save(eticket);

	}

	public Ticket cancelTicket(int ticketid) {

		Ticket ticket = ticketrepo.findById(ticketid).get();

		ticketrepo.deleteById(ticketid);

		return ticket;

	}

	public List<Ticket> getTicketFromPlaceOrToPlace(String fromplace, String toplace) {
		return ticketrepo.findByFromplaceOrToplace(fromplace, toplace);
	}

	public float getAveragePrice(String fromplace)

	{

		List<Ticket> ticket = ticketrepo.averagePrice(fromplace);

		float avg_price = 0;
		for (Ticket t : ticket) {

			avg_price += t.getPrice();

		}

		avg_price = avg_price / ticket.size();
		return avg_price;

	}
	
	public List<Ticket> getEconomyTickets(String fromplace, String toplace, float price){
		
		return ticketrepo.findByFromplaceOrToplaceAndPriceLessThan(fromplace, toplace, price);
		
	}

}
