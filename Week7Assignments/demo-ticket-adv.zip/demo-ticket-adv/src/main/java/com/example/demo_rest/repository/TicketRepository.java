package com.example.demo_rest.repository;


import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.demo_rest.model.Ticket;

@Repository

public interface TicketRepository extends JpaRepository<Ticket,Integer> 

//public interface TicketRepository extends CrudRepository<Ticket,Integer>

//public interface TicketRepository extends PagingAndSortingRepository<Ticket,Integer>

{
	

	
public List<Ticket> findByFromplaceOrToplace(String fromplace, String toplace);


@Query("SELECT w FROM Ticket w WHERE w.fromplace=:fromplace")

List<Ticket> averagePrice(@Param("fromplace" ) String str);

public List<Ticket> findByFromplaceOrToplaceAndPriceLessThan(String fromplace,String toplace,float price);
}



