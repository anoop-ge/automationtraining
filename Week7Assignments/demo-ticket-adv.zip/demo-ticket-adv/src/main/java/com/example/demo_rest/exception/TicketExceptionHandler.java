package com.example.demo_rest.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class TicketExceptionHandler {

	@ExceptionHandler(InvalidTicketIDException.class)
	ResponseEntity<String> met(InvalidTicketIDException excep){
		return new ResponseEntity<String>(excep.getMessage(), HttpStatus.NOT_FOUND);
	}
	

	@ExceptionHandler(InvalidPlaceNameException.class)
	ResponseEntity<String> handler(InvalidPlaceNameException excep){
		return new ResponseEntity<String>(excep.getMessage(), HttpStatus.BAD_REQUEST);
	}
}
